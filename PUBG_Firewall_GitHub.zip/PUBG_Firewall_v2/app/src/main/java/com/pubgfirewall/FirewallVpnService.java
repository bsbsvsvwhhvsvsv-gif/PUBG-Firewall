package com.pubgfirewall;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FirewallVpnService extends VpnService implements Runnable {
    private static final String TAG = "PUBGFirewall";
    private static boolean running = false;
    private Thread thread;
    private ParcelFileDescriptor iface;
    private FilterManager filters;

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        filters = new FilterManager(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_STICKY;

        Builder b = new Builder();
        b.setSession("PUBG Firewall");
        b.addAddress("10.0.0.2", 32);
        b.addRoute("0.0.0.0", 0);
        b.addDnsServer("8.8.8.8");
        b.setBlocking(true);

        try {
            iface = b.establish();
            if (iface == null) {
                stopSelf();
                return START_NOT_STICKY;
            }

            running = true;

            // Simple notification
            PendingIntent pi = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);

            Notification n = new Notification.Builder(this)
                .setContentTitle("PUBG Firewall")
                .setContentText("Blocking anti-cheat servers")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();

            startForeground(1, n);

            thread = new Thread(this, "PUBGFirewall");
            thread.start();

            Log.i(TAG, "Started - blocking " + filters.getHostCount() + " hosts");

        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
            stopSelf();
            return START_NOT_STICKY;
        }

        return START_STICKY;
    }

    @Override
    public void run() {
        try {
            FileChannel in = new FileInputStream(iface.getFileDescriptor()).getChannel();
            FileChannel out = new FileOutputStream(iface.getFileDescriptor()).getChannel();
            ByteBuffer buf = ByteBuffer.allocate(32767);

            while (running) {
                buf.clear();
                int len = in.read(buf);
                if (len > 0) {
                    buf.flip();
                    // Simple pass-through (filtering done at DNS level)
                    buf.position(0);
                    out.write(buf);
                }
            }
            in.close();
            out.close();
        } catch (IOException e) {
            Log.e(TAG, "VPN error: " + e.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (thread != null) thread.interrupt();
        if (iface != null) {
            try { iface.close(); } catch (IOException e) {}
        }
        super.onDestroy();
    }
}