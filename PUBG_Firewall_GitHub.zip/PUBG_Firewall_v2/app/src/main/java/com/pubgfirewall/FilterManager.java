package com.pubgfirewall;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class FilterManager {
    private Set<String> packages = new HashSet<>();
    private Set<String> hosts = new HashSet<>();
    private Set<String> ips = new HashSet<>();
    private Set<Integer> ports = new HashSet<>();

    public FilterManager(Context ctx) {
        try {
            BufferedReader r = new BufferedReader(
                new InputStreamReader(ctx.getResources().openRawResource(R.raw.filters)));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();

            JSONObject data = new JSONObject(sb.toString());
            JSONArray filters = data.getJSONArray("filters");

            for (int i = 0; i < filters.length(); i++) {
                JSONObject f = filters.getJSONObject(i);
                String pkg = f.optString("pkg1Name", "");
                String server = f.optString("server", "");
                String type = f.optString("serverStrType", "");
                int port = f.optInt("port", -1);
                String wifi = f.optString("wifi", "none");
                String mobile = f.optString("mobile", "none");

                if (!pkg.isEmpty() && !"*".equals(pkg)) packages.add(pkg);

                if (("deny".equals(wifi) || "deny".equals(mobile)) && !"*".equals(server)) {
                    if ("host".equals(type)) hosts.add(server);
                    else if ("ip4".equals(type)) ips.add(server);
                }
                if (port > 0 && ("deny".equals(wifi) || "deny".equals(mobile))) {
                    ports.add(port);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getPackageCount() { return packages.size(); }
    public int getHostCount() { return hosts.size(); }
    public int getIpCount() { return ips.size(); }
    public int getPortCount() { return ports.size(); }
    public Set<String> getBlockedHosts() { return hosts; }
    public Set<String> getBlockedIps() { return ips; }
    public Set<Integer> getBlockedPorts() { return ports; }
}