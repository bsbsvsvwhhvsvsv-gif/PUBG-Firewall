package com.pubgfirewall;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 1;
    private Button btnToggle;
    private TextView tvStatus;
    private TextView tvInfo;
    private boolean active = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToggle = findViewById(R.id.btnToggle);
        tvStatus = findViewById(R.id.tvStatus);
        tvInfo = findViewById(R.id.tvInfo);

        // Load filter stats
        FilterManager fm = new FilterManager(this);
        tvInfo.setText("Packages: " + fm.getPackageCount() +
                       " | Hosts: " + fm.getHostCount() +
                       " | IPs: " + fm.getIpCount() +
                       " | Ports: " + fm.getPortCount());

        btnToggle.setOnClickListener(v -> toggle());
        updateUI();
    }

    private void toggle() {
        if (active) {
            stopService(new Intent(this, FirewallVpnService.class));
            active = false;
            updateUI();
        } else {
            Intent i = VpnService.prepare(this);
            if (i != null) {
                startActivityForResult(i, VPN_REQUEST);
            } else {
                onActivityResult(VPN_REQUEST, RESULT_OK, null);
            }
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == VPN_REQUEST && res == RESULT_OK) {
            startService(new Intent(this, FirewallVpnService.class));
            active = true;
            updateUI();
            Toast.makeText(this, "Firewall Active!", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateUI() {
        if (active) {
            tvStatus.setText("FIREWALL ACTIVE");
            tvStatus.setTextColor(Color.parseColor("#00E676"));
            btnToggle.setText("Disable Firewall");
        } else {
            tvStatus.setText("FIREWALL OFF");
            tvStatus.setTextColor(Color.parseColor("#FF5252"));
            btnToggle.setText("Enable Firewall");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        active = FirewallVpnService.isRunning();
        updateUI();
    }
}