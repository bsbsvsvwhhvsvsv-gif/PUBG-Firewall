# PUBG Firewall 🔥

**Auto-build APK via GitHub Actions**

## How to use:

### 1. Fork this repo (or create new)
- Go to github.com
- Create new repository
- Upload these files

### 2. Trigger build
- Go to **Actions** tab
- Click **"Build APK"**
- Click **"Run workflow"**

### 3. Download APK
- Wait 5-10 minutes
- Go to **Actions** → latest run
- Download `app-debug.apk` from artifacts

## Features:
- ✅ No Root required
- ✅ 700+ PUBG filters pre-loaded
- ✅ Auto-blocks anti-cheat servers
- ✅ Open Source (GPL v3)

## Manual build:
```bash
./gradlew assembleDebug
```
